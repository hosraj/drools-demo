
package com.wasl.drooldemo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.wasl.drooldemo.entity.Table;

public interface TableRepository extends MongoRepository<Table, Long> {
}
