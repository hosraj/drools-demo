package com.wasl.drooldemo.service;

import com.wasl.drooldemo.entity.CompanyTable;
import com.wasl.drooldemo.repository.CompanyTableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyTableService {

    @Autowired
    private CompanyTableRepository companyTableRepository;

    public List<CompanyTable> getAllCompanyTables() {
        return companyTableRepository.findAll();
    }

    public CompanyTable getCompanyTableById(Long id) {
        return companyTableRepository.findById(id).orElse(null);
    }

    public CompanyTable saveCompanyTable(CompanyTable companyTable) {
        return companyTableRepository.save(companyTable);
    }

    public void deleteCompanyTable(Long id) {
        companyTableRepository.deleteById(id);
    }
}
