
package com.wasl.drooldemo.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.io.Serializable;

@Document(collection = "tables")
public class Table implements Serializable {

    @Id
    private Long id;
    private String name;

    public Table() {}

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Table(Long id, String name) {
        this.id = id;
        this.name = name;
    }
}
